package suite.reusable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.bettercloud.vault.json.ParseException;

public class UpdateConnectivityStatus {

	public static String returnDateAndTime() {
		String pattern1 = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);
		String date1 = simpleDateFormat1.format(new Date());
		return date1;

	}

	public String utcTime(String utcTime, String days) throws Exception {
		int newdays = Integer.parseInt(utcTime.split("T")[0].split("-")[1]) + Integer.parseInt(days);
		utcTime = utcTime.replace(utcTime.split("T")[0].split("-")[1], String.valueOf(newdays));
		utcTime = utcTime.replace(".000Z", "");
		utcTime = utcTime.replace("T", " ");
		return utcTime;
	}

	public String addDaysToUTCDateTime(String utcTime, String days) throws Exception {
		String oldDate = utcTime;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar calendar = Calendar.getInstance();
		try {

			calendar.setTime(simpleDateFormat.parse(oldDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		calendar.add(Calendar.DAY_OF_MONTH, Integer.parseInt(days));
		String newDate = simpleDateFormat.format(calendar.getTime());
		utcTime = utcTime.replace(utcTime.split("T")[0], newDate);
		return utcTime;
	}

	public String subMinutesToUTCDateTime(String utcTime, String minutes) throws Exception {
		Date date = null;
		String str = utcTime.split("T")[1];
		DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		try {
			date = formatter.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, -Integer.parseInt(minutes));
		formatter = new SimpleDateFormat("HH:mm:ss");
		str = formatter.format(calendar.getTime());
		utcTime = utcTime.replace(utcTime.split("T")[1], str);
		utcTime = utcTime.replace("T", " ");
		return utcTime;
	}

	public String subMinutesToUTCDateTimeTZ(String utcTimeTZ, String minutes) throws Exception {
		Date date = null;
		String str = utcTimeTZ.split("T")[1];
		DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		try {
			date = formatter.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, -Integer.parseInt(minutes));
		formatter = new SimpleDateFormat("HH:mm:ss");
		str = formatter.format(calendar.getTime());
		utcTimeTZ = utcTimeTZ.replace(utcTimeTZ.split("T")[1], str) + "Z";
		return utcTimeTZ;
	}

	public String addMinutesToUTCDateTimeTZ(String utcTimeTZ, String minutes) throws Exception {
		Date date = null;
		String str = utcTimeTZ.split("T")[1];
		DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		try {
			date = formatter.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, Integer.parseInt(minutes));
		formatter = new SimpleDateFormat("HH:mm:ss");
		str = formatter.format(calendar.getTime());
		utcTimeTZ = utcTimeTZ.replace(utcTimeTZ.split("T")[1], str) + "Z";
		return utcTimeTZ;
	}

	public String subDayFromUTCDateTime(String utcTime, String days) throws Exception {
		String oldDate = utcTime.split("T")[0];
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar calendar = Calendar.getInstance();
		try {

			calendar.setTime(simpleDateFormat.parse(oldDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		calendar.add(Calendar.DAY_OF_MONTH, -Integer.parseInt(days));
		String newDate = simpleDateFormat.format(calendar.getTime());
		utcTime = utcTime.replace(".000Z", "");
		utcTime = utcTime.replace(utcTime.split("T")[0], newDate);
		utcTime = utcTime.replace("T", " ");
		return utcTime;
	}
	
	public String subDayFromUTCDateTimeTZ(String utcTime, String days) throws Exception {
		String oldDate = utcTime.split("T")[0];
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar calendar = Calendar.getInstance();
		try {

			calendar.setTime(simpleDateFormat.parse(oldDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		calendar.add(Calendar.DAY_OF_MONTH, -Integer.parseInt(days));
		String newDate = simpleDateFormat.format(calendar.getTime());
		utcTime = utcTime.replace(".000Z", "");
		utcTime = utcTime.replace(utcTime.split("T")[0], newDate);
		utcTime = utcTime.replace(utcTime.split("T")[1], oldDate) + "Z";
		return utcTime;
	}
}
