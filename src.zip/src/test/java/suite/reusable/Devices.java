package suite.reusable;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Devices {

	public static JSONArray getDeviceList() {
		return deviceList;
	}

	public static void setDeviceList(JSONArray deviceList) {
		Devices.deviceList = deviceList;
	}

	public static int getDevices() {
		return devices;
	}

	public static void setDevices(int devices) {
		Devices.devices = devices;
	}

	public static int devices = 0;
	public static JSONArray deviceList;

	public static void getNumberofDevicesConfigured(String jsonResponse) {
		JSONParser a = new JSONParser();
		try {
			deviceList = (JSONArray) (a.parse(jsonResponse));
			System.out.println("the number of devices configured = " + deviceList.size());
			devices = deviceList.size();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
