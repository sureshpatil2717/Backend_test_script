
package suite.reusable;

import java.io.IOException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;



public class ServiceTokenUtility {

	
	
	public ServiceTokenUtility () {
	}
	/**
	 * Generate the RSA JWT Token using private key reading from property file.
	 * 
	 * @return - String.
	 * 
	 */

	public String getJWTWithRsa(String privateKey,String subject,String serviceId,String audience ) {
		//read the private key from the vault
		
		privateKey = privateKey.replace("-----BEGIN RSA PRIVATE KEY-----", "");
		privateKey = privateKey.replace("-----END RSA PRIVATE KEY-----", "");
		byte[] encodedKey = Base64.getDecoder().decode(privateKey);
		ASN1Sequence seq = pkcsFormat(encodedKey);
		String token = null;
		try {
			byte[] privKey = seq.getEncoded("DER");
			KeyFactory kf = KeyFactory.getInstance("RSA");
			PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privKey);
			PrivateKey privKey1 = kf.generatePrivate(keySpec);
			token = generateJwtToken(privKey1,subject,serviceId,audience);
		} catch (InvalidKeySpecException | IOException | NoSuchAlgorithmException e) {
			e.getMessage();
		}
		
		return token;
	}

	/**
	 * Add PKCS#8 formatting
	 * 
	 * @return - ASN1Sequence
	 * 
	 */

	private ASN1Sequence pkcsFormat(byte[] encodedKey) {
		/* Add PKCS#8 formatting */
		ASN1EncodableVector v = new ASN1EncodableVector();
		v.add(new ASN1Integer(0));
		ASN1EncodableVector v2 = new ASN1EncodableVector();
		v2.add(new ASN1ObjectIdentifier(PKCSObjectIdentifiers.rsaEncryption.getId()));
		v2.add(DERNull.INSTANCE);
		v.add(new DERSequence(v2));
		v.add(new DEROctetString(encodedKey));
		ASN1Sequence seq = new DERSequence(v);
		return seq;
	}

	/**
	 * 
	 * Logic to Generate the JWT provided by reading property like
	 * serviceId,audience and subject
	 * 
	 * @return - String.
	 * 
	 */

	private String generateJwtToken(PrivateKey privateKey,String subject,String serviceId,String audience) {
		return  Jwts.builder().setSubject(subject)
				.setExpiration(new Date(new Date().getTime() + 1000 * 60 * 110)).setIssuer(serviceId)
				.setAudience(audience).signWith(SignatureAlgorithm.RS256, privateKey).compact();
	}


	
}
