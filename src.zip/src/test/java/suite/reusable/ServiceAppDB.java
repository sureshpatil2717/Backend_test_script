package suite.reusable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;
import java.util.UUID;

public class ServiceAppDB {

	public static Connection conn = null;
	public static Connection rdsConnection = null;
	static String sql = null;
	public static String device_hsdp_id = "";
	public static String transaction_id = "";
	public static String id = "";
	public static String organization_type = "";
	public static String gateway_type = "";
	public static String response_json;
	public static String hsdp_id = "";
	public static String device_category = "";
	public static String device_name = "";
	public static String device_serial_number = "";
	public static String device_display_name = "";
	
	public static String getDevice_name() {
		return device_name;
	}
	public static void setDevice_name(String device_name) {
		ServiceAppDB.device_name = device_name;
	}
	public static String getTransaction_id() {
		return transaction_id;
	}
	public static void setTransaction_id(String transaction_id) {
		ServiceAppDB.transaction_id = transaction_id;
	}
	public static String getDevice_serial_number() {
		return device_serial_number;
	}
	public static void setDevice_serial_number(String device_serial_number) {
		ServiceAppDB.device_serial_number = device_serial_number;
	}
	public static String getDevice_display_name() {
		return device_display_name;
	}

	public static void setDevice_display_name(String device_display_name) {
		ServiceAppDB.device_display_name = device_display_name;
	}

	public static int gateway_id;

	public static int getGateway_id() {
		return gateway_id;
	}

	public static String getDevice_category() {
		return device_category;
	}

	public static void setDevice_category(String device_category) {
		ServiceAppDB.device_category = device_category;
	}

	public static void setGateway_id(int gateway_id) {
		ServiceAppDB.gateway_id = gateway_id;
	}

	public static String getId() {
		return id;
	}

	public static String getResponse_json() {
		return response_json;
	}

	public static void setResponse_json(String response_json) {
		ServiceAppDB.response_json = response_json;
	}

	public static String getHsdp_id() {
		return hsdp_id;
	}

	public static void setHsdp_id(String hsdp_id) {
		ServiceAppDB.hsdp_id = hsdp_id;
	}

	public static void setId(String id) {
		ServiceAppDB.id = id;
	}

	public static String getGateway_type() {
		return gateway_type;
	}

	public static void setGateway_type(String gateway_type) {
		ServiceAppDB.gateway_type = gateway_type;
	}

	public static String practice_id = "";
	private static String device_type;

	public static String getPractice_id() {
		return practice_id;
	}

	public static void setPractice_id(String practice_id) {
		ServiceAppDB.practice_id = practice_id;
	}

	public static String getOrganization_type() {
		return organization_type;
	}

	public static void setOrganization_type(String organization_type) {
		ServiceAppDB.organization_type = organization_type;
	}

	public static String device_or_gateway;
	public static String connectivity_status;
	public static Date connectivity_status_time;
	public static String connectivity_status_time_String;
	public static String devicetype_insert = "";
	public static String device_or_gateway_insert = "";
	public static String connectivity_status_time_insert = "";
	public static String connectivity_status_insert = "";
	public static String sqlquerry = "";

	// added for insert to db

	public static String[] device_type_DB = { "Lenstar", "EPIC", "Cerner", "DML" };
	public static String[] devicegateway = { "true", "false" };

	public static String getConnectivity_status() {
		return connectivity_status;
	}

	public static void setConnectivity_status(String connectivity_status) {
		ServiceAppDB.connectivity_status = connectivity_status;
	}

	public static void main123() throws UnsupportedOperationException {
		UUID gfg = UUID.randomUUID();

		// checking this UUID
		System.out.println("UUID: " + gfg);
	}

	public static void RDSDB_Connection(String connection_url) throws Exception {
		try {
			// fetchUsrPwd();
			Class.forName("org.postgresql.Driver");
			if (rdsConnection == null) {
				System.out.println("Connection to RDS DB initiated.");
				rdsConnection = java.sql.DriverManager.getConnection(connection_url);
			}
			System.out.println("Connection to RDS DB has been established.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static ServiceAppDB getDeviceHsdpIdTime(String device_hsdp_id) throws ParseException {
		sql = "select * from public.tbl_heartbeat where device_hsdp_id = ? ";
		ServiceAppDB list = new ServiceAppDB();
		Date d5 = null;
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt = rdsConnection.prepareStatement(sql);
			pstmt.setString(1, device_hsdp_id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

				ServiceAppDB.setDevice_hsdp_id((String) rs.getObject("device_hsdp_id"));
				device_hsdp_id = (String) rs.getObject("device_hsdp_id");
				System.out.println("PracticeId :" + device_hsdp_id);

				final SimpleDateFormat converter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				converter.setTimeZone(TimeZone.getTimeZone("IST"));
				System.out.println(rs.getObject("connectivity_status_time"));

				String d4 = converter.format(rs.getObject("connectivity_status_time"));

				ServiceAppDB.setConnectivity_status_time_String((d4));
				device_hsdp_id = rs.getString("device_hsdp_id");
			}
		} catch (SQLException e) {

		}
		return list;
	}

	public static ServiceAppDB getLogMessage(String hsdp_id) throws ParseException {
		sql = "SELECT * FROM public.tbl_devicelog_blobs where hsdp_id = ? ";
		ServiceAppDB list = new ServiceAppDB();
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt = rdsConnection.prepareStatement(sql);
			pstmt.setString(1, hsdp_id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				ServiceAppDB.setHsdp_id((String) rs.getObject("hsdp_id"));
				hsdp_id = (String) rs.getObject("hsdp_id");
				System.out.println("PracticeId :" + hsdp_id);

				ServiceAppDB.setTransaction_id((String) rs.getObject("transaction_id"));
				transaction_id = (String) rs.getObject("transaction_id");
				System.out.println("setTransaction_id :" + transaction_id);
				
				final SimpleDateFormat converter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				converter.setTimeZone(TimeZone.getTimeZone("UTC"));
				System.out.println(rs.getObject("blob_creation_datetime"));

				String d4 = converter.format(rs.getObject("blob_creation_datetime"));

				ServiceAppDB.setConnectivity_status_time_String((d4));
			}
		} catch (SQLException e) {

		}
		return list;
	}

	public static void deleteRecord(String device_hsdp_id) {
		sql = "DELETE from public.tbl_heartbeat where device_hsdp_id = ? ";
		try {
			System.out.println("sql3:" + sql);
			PreparedStatement pstmt1 = rdsConnection.prepareStatement(sql);
			pstmt1.setString(1, device_hsdp_id);
			int abc = pstmt1.executeUpdate();
			System.out.println(abc);
		} catch (SQLException e) {

		}
	}

	public static void deleteRecordFromBlob(String hsdp_id) {
		sql = "DELETE from public.tbl_devicelog_blobs where hsdp_id = ? ";
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt1 = rdsConnection.prepareStatement(sql);
			pstmt1.setString(1, hsdp_id);
			int abc = pstmt1.executeUpdate();
			System.out.println(abc);
		} catch (SQLException e) {

		}
	}

	public static void Close_RDS_Connection() {
		try {
			if (rdsConnection != null) {
				System.out.println("Closing the RDS DB connection \n ");
				if (!rdsConnection.isClosed()) {
					rdsConnection.close();
					rdsConnection = null;
				}
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());

		}
	}

	public static String getDevice_type() {
		return device_type;
	}

	public static void setDevice_type(String device_type) {
		ServiceAppDB.device_type = device_type;
	}

	public static String getDevice_hsdp_id() {
		return device_hsdp_id;
	}

	public static void setDevice_hsdp_id(String device_hsdp_id) {
		ServiceAppDB.device_hsdp_id = device_hsdp_id;
	}

	public static Date getConnectivity_status_time() {
		return connectivity_status_time;
	}

	public static void setConnectivity_status_time(Date connectivity_status_time) {
		ServiceAppDB.connectivity_status_time = connectivity_status_time;
	}

	public static String getConnectivity_status_time_String() {
		return connectivity_status_time_String;
	}

	public static void setConnectivity_status_time_String(String connectivity_status_time_String) {
		ServiceAppDB.connectivity_status_time_String = connectivity_status_time_String;
	}
	// Added for Insertion (2299)

	public static String returnRandomString() {
		String random = (device_type_DB[new Random().nextInt(device_type_DB.length)]);
		return random;
	}

	public static void DB_Connection(String connection_url) {
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = java.sql.DriverManager.getConnection(connection_url);
			System.out.println("Connection to ORA DB has been established.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static void insert_to_DB_Values() {
		System.out.println("insert_to_DB_Values are ....");
		device_hsdp_id = RandomUtil.randomGUID();
		devicetype_insert = RandomUtil.returnRandomString(device_type_DB);
		device_or_gateway_insert = RandomUtil.returnRandomString(devicegateway);
		connectivity_status_time_insert = RandomUtil.localToUTC() + "+00";
		System.out.println("device_hsdp_id: " + device_hsdp_id + " devicetype_insert: " + devicetype_insert
				+ " device_or_gateway_insert: " + device_or_gateway_insert + "connectivity_status_time_insert: "
				+ connectivity_status_time_insert);
	}

	public static Statement insert_to_DB(String status, String timestamp, String devicetype, String deviceorgateway,
			int id) {
		Statement querryStatement = null;
		insert_to_DB_Values();
		connectivity_status_insert = status;
		devicetype_insert = devicetype;
		device_or_gateway_insert = deviceorgateway;
		int id1 = id;
		String insertQuery = "INSERT INTO public.tbl_heartbeat "
				+ "(id,device_hsdp_id, device_type, device_or_gateway, connectivity_status_time, "
				+ "connectivity_status)" + " VALUES ('" + id1 + "', '" + device_hsdp_id + "','" + devicetype_insert
				+ "','" + device_or_gateway_insert + "','" + connectivity_status_time_insert + "','"
				+ connectivity_status_insert + "')";
		sqlquerry = insertQuery;
		System.out.println("Patient Table insert query: " + sqlquerry);
		try {
			if (rdsConnection != null) {
				querryStatement = rdsConnection.createStatement();
				querryStatement.execute(sqlquerry);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return querryStatement;
	}

	public static void insert_to_DB_Values1059() {
		System.out.println("insert_to_DB_Values are ....");
		device_hsdp_id = RandomUtil.randomGUID();
		devicetype_insert = RandomUtil.returnRandomString(device_type_DB);
		device_or_gateway_insert = RandomUtil.returnRandomString(devicegateway);
		connectivity_status_time_insert = RandomUtil.localToUTC() + "+00";
		System.out.println("device_hsdp_id: " + device_hsdp_id + " devicetype_insert: " + devicetype_insert
				+ " device_or_gateway_insert: " + device_or_gateway_insert + "connectivity_status_time_insert: "
				+ connectivity_status_time_insert);
	}

	public static Statement insert_to_DB1059(String pacid, String reqbody, int id) {
		Statement querryStatement = null;
		int tbl_id = id;
		practice_id = pacid;
		response_json = reqbody;
		String insertQuery = "INSERT INTO public.tbl_registered_devices " + "(device_hsdp_id,practice_id, response_json)"
				+ " VALUES ( '" + tbl_id + "','" + practice_id + "','" + response_json + "')";
		sqlquerry = insertQuery;
		System.out.println("Patient Table insert query: " + sqlquerry);
		try {
			if (rdsConnection != null) {
				querryStatement = rdsConnection.createStatement();
				querryStatement.execute(sqlquerry);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return querryStatement;
	}

	public static String getdataFromregister(String practice_id) throws ParseException {
		sql = "SELECT * FROM public.tbl_registered_devices where practice_id = ? ";
		ServiceAppDB list = new ServiceAppDB();
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt = rdsConnection.prepareStatement(sql);
			pstmt.setString(1, practice_id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString("response_json"));
				String abc = rs.getString("response_json");
				return abc;
			}
		} catch (SQLException e) {

		}
		return null;
	}

	public static void deleteRecordFromregister(String practice_id) {
		sql = "DELETE from public.tbl_registered_devices where practice_id = ? ";
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt1 = rdsConnection.prepareStatement(sql);
			pstmt1.setString(1, practice_id);
			int abc = pstmt1.executeUpdate();
			System.out.println(abc);
		} catch (SQLException e) {

		}
	}

	public static ServiceAppDB getPracticeDetails(String id) throws ParseException {
		sql = "SELECT * FROM public.tbl_practices where id = ? ";
		ServiceAppDB list = new ServiceAppDB();
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt = rdsConnection.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

				ServiceAppDB.setId((String) rs.getObject("id"));
				id = (String) rs.getObject("id");
				System.out.println("PracticeId :" + id);

				ServiceAppDB.setOrganization_type((String) rs.getObject("organization_type"));
				organization_type = (String) rs.getObject("organization_type");
				System.out.println("organization_type :" + organization_type);
			}
		} catch (SQLException e) {

		}
		return list;
	}

	public static ServiceAppDB getGatewayDetails(String practice_id) throws ParseException {
		sql = "SELECT * FROM public.tbl_gateway_devices where practice_id = ? ";
		ServiceAppDB list = new ServiceAppDB();
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt = rdsConnection.prepareStatement(sql);
			pstmt.setString(1, practice_id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

				ServiceAppDB.setId((String) rs.getObject("practice_id"));
				id = (String) rs.getObject("practice_id");
				System.out.println("PracticeId :" + practice_id);

				ServiceAppDB.setGateway_type((String) rs.getObject("gateway_type"));
				gateway_type = (String) rs.getObject("gateway_type");
				System.out.println("gateway_type :" + gateway_type);

			}
		} catch (SQLException e) {

		}
		return list;
	}

	public static ServiceAppDB getDevicedetails(String local_ae_title) throws ParseException {
		sql = "SELECT * FROM public.tbl_sitesurvey_devices where local_ae_title = ? ";
		ServiceAppDB list = new ServiceAppDB();
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt = rdsConnection.prepareStatement(sql);
			pstmt.setString(1, local_ae_title);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

				ServiceAppDB.setDevice_name((String) rs.getObject("device_name"));
				device_name = (String) rs.getObject("device_name");
				System.out.println("device_name :" + device_name);

				ServiceAppDB.setDevice_type((String) rs.getObject("device_type"));
				device_type = (String) rs.getObject("device_type");
				System.out.println("device_type :" + device_type);

				ServiceAppDB.setDevice_category((String) rs.getObject("device_category"));
				device_category = (String) rs.getObject("device_category");
				System.out.println("device_category :" + device_category);

				ServiceAppDB.setDevice_serial_number((String) rs.getObject("device_serial_number"));
				device_serial_number = (String) rs.getObject("device_serial_number");
				System.out.println("device_serial_number :" + device_serial_number);
				
				ServiceAppDB.setDevice_display_name((String) rs.getObject("device_display_name"));
				device_display_name = (String) rs.getObject("device_display_name");
			}
		} catch (SQLException e) {

		}
		return list;
	}

	public static void deleteDeviceDetails(String practice_id) {
		sql = "DELETE from public.tbl_sitesurvey_devices where local_ae_title = ? ";
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt1 = rdsConnection.prepareStatement(sql);
			pstmt1.setString(1, practice_id);
			int abc = pstmt1.executeUpdate();
			System.out.println(abc);
		} catch (SQLException e) {

		}
	}
	
	public static void deleteDeviceDetailswithprac(String practice_id) {
		sql = "DELETE from public.tbl_sitesurvey_devices where gateway_id in (select id FROM tbl_gateway_devices where practice_id = ?) ";
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt1 = rdsConnection.prepareStatement(sql);
			pstmt1.setString(1, practice_id);
			int abc = pstmt1.executeUpdate();
			System.out.println(abc);
		} catch (SQLException e) {

		}
	}

	public static void deleteGatewayDetails(String practice_id) {
		sql = "DELETE from public.tbl_gateway_devices where practice_id = ? ";
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt1 = rdsConnection.prepareStatement(sql);
			pstmt1.setString(1, practice_id);
			int abc = pstmt1.executeUpdate();
			System.out.println(abc);
		} catch (SQLException e) {

		}
	}

	public static void deletePracticeDetails(String practice_id) {
		sql = "DELETE from public.tbl_practices where id = ? ";
		try {
			System.out.println("sql:" + sql);
			PreparedStatement pstmt1 = rdsConnection.prepareStatement(sql);
			pstmt1.setString(1, practice_id);
			int abc = pstmt1.executeUpdate();
			System.out.println(abc);
		} catch (SQLException e) {

		}
	}

	public static String path_to_log_files = "http://localhost/logs33";
	public static String path_to_audit_files = "http://localhost/logs33";
	public static String path_to_device_status = "http://localhost/logs33";
	public static String path_to_io_bridge = "http://localhost/logs33";
	public static String path_to_dicom_store = "http://localhost/logs33";
	public static String path_to_iob_bidirectional_path = "http://localhost/logs33";
	public static String lenstar_path_to_iobridge = "http://localhost/logs33";
	public static String proxy_ip_address = "10.23.26";
	public static String proxy_port = "0";
	public static String reference_id = null;
	public static String proxy_ip_address_updated = "10.23.26.105";

	public static Statement insert_to_Practice(String timestamp, String devicetype, String orgtype) {
		Statement querryStatement = null;
		practice_id = timestamp;
		String practice_name = devicetype;
		String orgType = orgtype;
		String insertQuery = "INSERT INTO public.tbl_practices "
				+ "(id, practice_name, organization_type, reference_id, path_to_log_files,path_to_audit_files,path_to_device_status,path_to_io_bridge,path_to_dicom_store,path_to_iob_bidirectional_path,proxy_ip_address,proxy_port,lenstar_path_to_iobridge)"
				+ " VALUES ( '" + practice_id + "','" + practice_name + "','" + orgType + "','" + reference_id + "','"
				+ path_to_log_files + "','" + path_to_audit_files + "','" + path_to_device_status + "','"
				+ path_to_io_bridge + "','" + path_to_dicom_store + "','" + path_to_iob_bidirectional_path + "','"
				+ proxy_ip_address + "','" + proxy_port + "','" + lenstar_path_to_iobridge + "')";
		sqlquerry = insertQuery;
		System.out.println("Patient Table insert query: " + sqlquerry);
		try {
			if (rdsConnection != null) {
				querryStatement = rdsConnection.createStatement();
				querryStatement.execute(sqlquerry);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return querryStatement;
	}

	public static String ip_address1 = "998.0.0.17";
	public static String port1 = "0";
	public static String gateway_type1 = "EMR";
	public static String gateway_creation_datetime = RandomUtil.localToUTC() + "+00";
	public static String gateway_update_datetime = RandomUtil.localToUTC() + "+00";
	public static int gatewayid_insert;
	public static int gatewayid_insert_increment;
	public static String gateway_type_updated = "DICOM";

	public static Statement insert_to_Gateway(int gatewayid, String practiceId) {
		Statement querryStatement = null;

		gatewayid_insert = gatewayid;
		String practiceid = practiceId;
		String insertQuery = "INSERT INTO public.tbl_gateway_devices "
				+ "(id, practice_id, ip_address, gateway_type,gateway_creation_datetime,gateway_update_datetime)"
				+ " VALUES ( '" + gatewayid_insert + "','" + practiceid + "','" + ip_address1 + "','" + gateway_type1
				+ "','" + gateway_creation_datetime + "','" + gateway_update_datetime + "')";
		sqlquerry = insertQuery;
		System.out.println("Patient Table insert query: " + sqlquerry);
		try {
			if (rdsConnection != null) {
				querryStatement = rdsConnection.createStatement();
				querryStatement.execute(sqlquerry);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return querryStatement;
	}

	public static String device_type1 = "Alcon";
	public static String device_category1 = "DICOM";
	public static String device_serial_number1 = "s3";
	public static String device_name1 = "Zeiss700";
	public static String storage_ae_title = "storescp";
	public static String storage_port = "5007";
	public static String worklist_ae_title = "mwlscp";
	public static String worklist_port = "5008";
	public static String local_ae_title = "IOLMaster7001";
	public static String xml_files_path = "";
	public static String ip_address = "10.23.26";
	public static String port = "0";
	public static String bidirectional_ip_address = "10.23.26";
	public static String bidirectional_port = "0";
	public static String version = "0";
	public static String device_manufacturer = "";
	public static String gateway_id1 = "http://localhost/logs33";

	public static Statement insert_to_Device(int timestamp, String localaetitle) {
		Statement querryStatement = null;
		gatewayid_insert = timestamp;
		local_ae_title = localaetitle;
		gatewayid_insert_increment = gatewayid_insert + 1;
		String insertQuery = "INSERT INTO public.tbl_sitesurvey_devices "
				+ "(id, device_type, device_category, device_serial_number, device_name,storage_ae_title,storage_port,worklist_ae_title,worklist_port,local_ae_title,xml_files_path,port,bidirectional_ip_address,bidirectional_port,version,device_manufacturer,gateway_id)"
				+ " VALUES ( '" + gatewayid_insert_increment + "','" + device_type1 + "','" + device_category1 + "','"
				+ device_serial_number1 + "','" + device_name1 + "','" + storage_ae_title + "','" + storage_port + "','"
				+ worklist_ae_title + "','" + worklist_port + "','" + local_ae_title + "','" + xml_files_path + "','"
				+ port + "','" + bidirectional_ip_address + "','" + bidirectional_port + "','" + version + "','"
				+ device_manufacturer + "','" + gatewayid_insert + "')";
		sqlquerry = insertQuery;
		System.out.println("Patient Table insert query: " + sqlquerry);
		try {
			if (rdsConnection != null) {
				querryStatement = rdsConnection.createStatement();
				querryStatement.execute(sqlquerry);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return querryStatement;
	}

	public static Statement insert_to_Facility(String timestamp, String devicetype, String orgtype) {
		Statement querryStatement = null;
		practice_id = timestamp;
		String practice_name = devicetype;
		String orgType = orgtype;
		String insertQuery = "INSERT INTO public.tbl_practices "
				+ "(id, practice_name, organization_type, reference_id, path_to_log_files,path_to_audit_files,path_to_device_status,path_to_io_bridge,path_to_dicom_store,path_to_iob_bidirectional_path,proxy_ip_address,proxy_port,lenstar_path_to_iobridge)"
				+ " VALUES ( '" + practice_id + "','" + practice_name + "','" + orgType + "','" + practice_id + "','"
				+ path_to_log_files + "','" + path_to_audit_files + "','" + path_to_device_status + "','"
				+ path_to_io_bridge + "','" + path_to_dicom_store + "','" + path_to_iob_bidirectional_path + "','"
				+ proxy_ip_address + "','" + proxy_port + "','" + lenstar_path_to_iobridge + "')";
		sqlquerry = insertQuery;
		System.out.println("Patient Table insert query: " + sqlquerry);
		try {
			if (rdsConnection != null) {
				querryStatement = rdsConnection.createStatement();
				querryStatement.execute(sqlquerry);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return querryStatement;
	}
}
