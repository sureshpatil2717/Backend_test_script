package suite.reusable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;
import java.util.UUID;

public class RandomUtil {

	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

	public static Random random = new Random();

	/*
	 * This method is used to get one random string with a length of 10
	 */
	public static String randomAlphaNumeric() {
		int count = 10;
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	// Added by Suchismitha
	/*
	 * This method is used to get one random string with a length as parameter
	 * Overloaded the method
	 */
	public static String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	/*
	 * This method is used to get a random float number
	 */
	public static float randomFloatNumber() {
		// float floatNumber = random.nextFloat() * 10 - 5;
		float floatNumber = random.nextFloat();
		floatNumber = Float.parseFloat(String.format("%.05f", floatNumber));
		if (floatNumber == 0.0 || floatNumber == 1.0) {
			return (float) 0.0270882;
		}
		if (random.nextBoolean()) {
			return floatNumber;
		} else
			return -(floatNumber);

	}

	/*
	 * This method is used to get a 2 digit number <100
	 */
	public static int random2DigitNumber() {
		int number = random.nextInt(99);
		number = Math.round(number);
		return number;
	}

	/*
	 * This method is used to get a 10digit number <100
	 */
	public static String random5DigitNumber() {
		int number = random.nextInt(99999);
		number = Math.round(number);
		return Integer.toString(number);
	}

	/*
	 * This method is used to get a random number based on the range provided to it
	 * as an input
	 */
	public static int randomNumerOnRange(int range) {
		return random.nextInt(range);
	}

	/*
	 * This method is used to get a 4 digit number and the return value will be in a
	 * 4 digit format
	 */
	public static String randomNumerWith4Digits() {
		return String.format("%04d", random.nextInt(10000));
	}

	/*
	 * This method is used to get random number based on the range provided to it as
	 * an input
	 */
	public static int randomNumberWithInRange(int start, int end) {
		return start + (int) Math.round(Math.random() * (end - start));
	}

	/*
	 * This method is used to generate random GUID and it return it as a String
	 */
	public static String randomGUID() {
		UUID guid = UUID.randomUUID();
		return guid.toString();
	}

	/*
	 * This method is used to get the current date
	 */
	public static String returnCurrentDate() {
		LocalDate currentDate = LocalDate.now();
		System.out.println("currentTime:" + currentDate.toString());
		return currentDate.toString();
	}

	/*
	 * This method is used to get the current time
	 */
	public static String returnCurrentTime() {
		LocalTime currentTime = LocalTime.now();
		System.out.println("currentTime:" + currentTime.toString());
		return currentTime.toString();
	}

	/*
	 * This method is used to get the current date and time
	 */
	public static String returnDateAndTime() {
		LocalDateTime dateNTime = LocalDateTime.now();
		return dateNTime.toString();
	}

	/*
	 * This method is used to get current month and date
	 */
	public static String returnMonthAndTime() {
		LocalDate date = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd");
		return formatter.format(date).toString();
	}

	/*
	 * This method is used to generate Date of Birth
	 */
	public static String randomDateOfBirth() {
		String year = String.valueOf(randomNumberWithInRange(1900, returnCurrentYear()));
		String monthNDate = returnMonthAndTime();
		String time = returnCurrentTime();
		return year + "-" + monthNDate + "T" + time;
	}

	/*
	 * This method is used to get current year
	 */
	public static int returnCurrentYear() {
		Calendar calendar = Calendar.getInstance();
		return calendar.get(Calendar.YEAR);
	}

	/*
	 * This method is used to get only seconds
	 */
	public static int returnSeconds() {
		Calendar calendar = Calendar.getInstance();
		return calendar.get(Calendar.SECOND);
	}

	/*
	 * This method is used to get a random int value from the integer array received
	 * as an input
	 */
	public static int returnRandomIntValue(int[] input) {
		int value = random.nextInt(input.length);
		return input[value];
	}

	/*
	 * This method is used to get a random String value from the String array
	 * received as an input
	 */
	public static String returnRandomString(String[] input) {
		int value = random.nextInt(input.length);
		return input[value];
	}

	/*
	 * This method is used to get the current date
	 */
	public static String returnCurrentGMTDate() {
		Calendar cal = Calendar.getInstance(TimeZone.getDefault());
		return cal.toString();
	}

	/*
	 * This method is used to get the current time
	 */
	public static String returnCurrentGMTTime() {
		LocalTime currentTime = LocalTime.now();
		return currentTime.toString();
	}

	public static String localToUTC() {
		Date localTime = new Date();
		DateFormat converter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		converter.setTimeZone(TimeZone.getTimeZone("GTM"));
		String abc = converter.format(localTime);
		System.out.println(abc);
		return abc;
	}

	public String addMinutesToUTCDateTime(String utcTime, String minutes) {
		Date date = null;
		String str = utcTime.split("T")[1];
		DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		try {
			date = formatter.parse(str);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, Integer.parseInt(minutes));
		formatter = new SimpleDateFormat("HH:mm:ss");
		str = formatter.format(calendar.getTime());
		utcTime = utcTime.replace(utcTime.split("T")[1], str);
		return utcTime;
	}

}