function init(text) {
    var temp = text
    var Base64 = Java.type('java.util.Base64');
    var encoded = Base64.getEncoder().encodeToString(text.bytes);
    return encoded;
}