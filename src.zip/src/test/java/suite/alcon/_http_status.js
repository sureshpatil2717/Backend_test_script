function getStatus(httpStatus) {
    if (httpStatus.expected === '#(expectedStatus)') {
        return httpStatus.default;
    }
    return httpStatus.expected;
}