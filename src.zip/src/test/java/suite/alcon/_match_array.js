function getMatch(arraysList) {
	var isMatch = false;
	var count = 0;
    if (arraysList.actual.length == arraysList.expected.length) {
    	isMatch = true;
        while (count < arraysList.expected.length) {
        	if (arraysList.actual.indexOf(arraysList.expected[count])== -1) {
        		isMatch = false;
        		break;
        	}
        	count++;
        }
    }
    return isMatch;
}