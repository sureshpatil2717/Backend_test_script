/*
 * (C) Koninklijke Philips Electronics N.V. 2018
 *
 * All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any
 * means, electronic, mechanical or otherwise, is prohibited without the prior written consent of
 * the copyright owner.
 *
 */

package suite;

import static junit.framework.TestCase.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.cloudfoundry.client.lib.CloudCredentials;
import org.cloudfoundry.client.lib.CloudFoundryClient;
import org.cloudfoundry.client.lib.HttpProxyConfiguration;
import org.cloudfoundry.client.lib.domain.CloudServiceInstance;
import org.junit.BeforeClass;
import org.junit.Test;

import com.intuit.karate.StringUtils;
import com.intuit.karate.cucumber.CucumberRunner;
import com.intuit.karate.cucumber.KarateStats;

import cucumber.api.CucumberOptions;
import gherkin.deps.com.google.gson.JsonObject;
import gherkin.deps.com.google.gson.JsonParser;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

@CucumberOptions (tags = { "~@ignore" }) // important: do not use @RunWith(Karate.class) !
public class SuiteParallelTest {

  private static final String CICD = "cicd";
  private static final Logger LOG = Logger.getLogger ("FIAMSuiteParallelTest");

  @BeforeClass
  public static void setup () throws Exception {

    if (!CICD.equalsIgnoreCase (System.getProperty ("karate.env"))) {
      return;
    }
  }

  @Test
  public void testParallel () {

    String karateOutputPath = "target/surefire-reports";
    String tc = System.getProperty ("karate.tc");
    int threadCount = 20; // Default thread count
    if (!StringUtils.isBlank (tc)) {
      threadCount = Integer.parseInt (tc);
    }

    LOG.info ("STARTING: Parallel Test Execution...");
    KarateStats stats = CucumberRunner.parallel (getClass (), threadCount, karateOutputPath);
    generateReport (karateOutputPath);
    LOG.info ("COMPLETED: Parallel Test Execution.");
    assertTrue ("There are suite scenario failures", stats.getFailCount () == 0);
  }

  private static void generateReport (String karateOutputPath) {

    Collection<File> jsonFiles =
        FileUtils.listFiles (new File (karateOutputPath), new String[] { "json" }, true);
    List<String> jsonPaths = new ArrayList<> (jsonFiles.size ());
    jsonFiles.forEach (file -> jsonPaths.add (file.getAbsolutePath ()));
    Configuration config = new Configuration (new File ("target"), "HealthSuite IAM TestSuite");
    ReportBuilder reportBuilder = new ReportBuilder (jsonPaths, config);
    reportBuilder.generateReports ();
  }
}
